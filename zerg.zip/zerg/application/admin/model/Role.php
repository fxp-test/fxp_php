<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/19
 * Time: 14:45
 */

namespace app\admin\model;

use think\Request;
use think\Db;
use think\Model;

class Role extends Base
{
	protected $hidden = ['id','password','phone','email','login_ip','update_time','create_time','out_time','login_time','role_id','login_s','sex_id','delete_id','state','remarks'];

    public function adminName(){
        return $this -> hasMany('Admin','role_id','id');
    }

	/***** 查询多条角色数据 *****/
	public static function getRoleAll(){
		return self::with(['adminName']) -> select();
	}

	/***** 添加角色 *****/
	public static function getRoleAdd($data){
		$role = model('Role');
		return $role -> save($data);
	}

	/***** 编辑角色 *****/
	public static function getRoleEdit($id,$data){
		return self::where('id','eq',$id) -> update($data);	
	}
}