<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/14
 * Time: 16:07
 */

namespace app\admin\model;

use think\Request;
use think\Db;
use think\Model;

class Admin extends Base
{
	protected $hidden = ['id','power_id','describe','update_time','create_time','delete_id','state'];

	public function role(){
		return $this -> belongsTo('Role','role_id','id');
	}

	/***** 登录时查询单条 *****/
	public static function getAdminLogin($name,$password){
		return self::with('role') -> where(['name'=>$name,'password'=>md5($password)]) -> find();
	}


	/***** 查询多条管理员数据 *****/
	public static function getAdminAll(){
		$admin = model('Admin');
		return $admin -> select();
}

	/***** 添加管理员数据 *****/
	public static function getAdminAdd($data){
		$admin = model('Admin');
		$data['password'] = md5($data['password']);
		unset($data['password_confirm']);
		return $admin -> save($data);
	}

	/***** 编辑管理员数据 *****/
	public static function getAdminEdit($id,$data){
		if (empty($data['password']) || empty($data['password_confirm'])){
			unset($data['password_confirm']);
			unset($data['password']);
			$data['update_time'] = time();
			return self::where('id','eq',$id) -> update($data);
		}else{
			if ($data['password'] != $data['password_confirm']) {
				return  error('您输入的密码不一致！',url('Admin/admin_edit',['id'=>$id]),'',1);
			}else{
				$data['password'] = md5($data['password']);
				unset($data['password_confirm']);
				$data['update_time'] = time();
				return self::where('id','eq',$id) -> update($data);
			}
		}
	}

	/***** 管理员登录更新 *****/
	public static function getLoginEdit($id,$datas){
		return self::where('id','eq',$id)  -> update($datas);
	}

	/***** 管理员退出更新 *****/
	public static function getLogoutEdit($field,$data){
		return self::where('name','eq',$field)  -> update($data);
	}



}