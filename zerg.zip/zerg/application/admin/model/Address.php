<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/23
 * Time: 14:48
 */

namespace app\admin\model;


class Address extends Base
{

}