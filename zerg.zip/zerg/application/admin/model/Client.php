<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/21
 * Time: 10:04
 */

namespace app\admin\model;

use think\Db;

class Client extends Base
{
    public function address()
    {
        return $this -> hasMany('Address', 'client_id', 'id') -> where('is_delete', '=', 0);
    }

    public static function getClientOne($id)
    {
        $result = Db::name('client') -> find($id);
        return $result;
    }

    public static function getClientList()
    {
        $result = Db::name('client') -> where('is_delete', '=', 0) -> paginate(10);
        return $result;
    }

    public static function getClientAll()
    {
        return Db::name('client') -> where('is_delete', '=', 0) -> select();
    }

    public static function addClient($data)
    {
        $id = $data['id'];
        if (isset($id)) {
            $result = Client::update($data);
        } else {
            $result = Client::save($data);
        }
        return $result;
    }

    public static function delClient($ids = [])
    {
        $result = model('client') -> where('id', 'in', $ids) -> update(['is_delete' => '1']);
        return $result;
    }

    public static function searchClient($data)
    {
        $result = model('client') -> where('name', 'like', '%' . $data . '%') -> select();
        return $result;
    }

    public static function getAddressListByID($cid)
    {
        $address = self::with(['address']) -> select($cid);
        return $address;
    }

    public static function addAddress($data)
    {
        if (isset($data['id'])) {
            $result = model('address') -> update($data);
        } else {
            $result = model('address') -> save($data);
        }
        return $result;
    }

    public static function getAddressOne($data)
    {
        $result = model('address') -> where('id', '=', $data) -> find();
        return $result;
    }

    public static function delAddress($id)
    {
        $result = model('address') -> where('id', '=', $id) -> update(['is_delete' => '1']);
        return $result;
    }


}