<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/15
 * Time: 10:56
 */

namespace app\admin\model;

use think\Model;

class Base extends Model
{
    /***** 设置当前时间 *****/
    protected $autoWriteTimestamp = true;

    /***** 查询单条数据 *****/
	public static function getModelOne($field, $one){
		return self::where([$field =>['eq',$one]]) -> find();
	}

    function object_to_array($obj){
        $arr = [];
        $_arr = is_object($obj) ? get_object_vars($obj) :$obj;
        foreach ($_arr as $key=>$val){
            $val = (is_array($val) || is_object($val)) ? $this->object_to_array($val):$val;
            $arr[$key] = $val;
        }
        return $arr;
    }
}