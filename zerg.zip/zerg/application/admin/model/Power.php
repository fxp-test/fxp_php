<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/20
 * Time: 10:37
 */

namespace app\admin\model;

use think\Request;
use think\Db;
use think\Model;

class Power extends Base
{
	/***** 查询多条权限数据 *****/
	public static function getPowerAll(){
		return self::order('auth') -> paginate(10);
	}

	/***** 添加权限 *****/
	public static function getPowerAdd($data){
		$power = model('Power');
		return $power -> insertGetId($data);
	}

	/***** 编辑权限 *****/
	public static function getPowerEdit($id,$data){
		return self::where('id','eq',$id) -> update($data);	
	}
}