<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/19
 * Time: 14:43
 */

namespace app\admin\controller;

use think\Controller;
use think\Request;
use think\Db;
use app\admin\model\Role as RoleModel;

class Role extends Base
{
	/***** 角色列表 *****/
	public function role_indexAction(){
        $adminpower = $this -> power();
		$this -> islogin();
    	$this -> controller();
        $role = RoleModel::getRoleAll();
        // var_dump($role);exit;
        $count = count(Db::name('Role') -> where('delete_id',0) -> select());
        $this->assign([
            'role'  => $role,
            'count' => $count,
            'adminpower' => $adminpower
        ]);
		return $this -> fetch();
	}


	/***** 添加角色 *****/
	public function role_addAction(){
		$this -> islogin();
		if (Request::instance()->isPost()) {
			$data = input('post.');
    		$role = RoleModel::getModelOne($field = 'name' , $one = $data['name']);
            if (!empty($role)){
	            $this -> error('角色已存在!','','',1);
	        }
    		$validate = Validate('RoleValidate');
            if (!$validate -> scene('add') -> check($data)) {
                $this -> error($validate -> getError());
            }          
            $result = RoleModel::getRoleAdd($data);
            if($result){
                return $this->success('添加成功！','','',1);
            } else {
                return $this->error('添加失败！','','',1);
            }
		}
		return $this -> fetch();
	}


	/***** 编辑角色 *****/
	public function role_editAction(){
		$this -> islogin();
		if (Request::instance() -> isGet()) {
            $id = input('get.id');
    		$role = RoleModel::getModelOne($field = 'id' , $data = $id);
    		$this->assign([
            	'role'  => $role
        	]);
    	}
		if (Request::instance()->isPost()) {
			$data = input('post.');
			$id = $data['id'];
    		$role = RoleModel::getModelOne($field = 'name' , $one = $data['name']);
            if (!empty($role)){
	            $this -> error('角色已存在!','','',1);
	        }
    		$validate = Validate('RoleValidate');
            if (!$validate -> scene('add') -> check($data)) {
                $this -> error($validate -> getError());
            }          
            $result = RoleModel::getRoleEdit($id,$data);
            if($result){
                return $this->success('编辑成功！',url('Role/role_edit',['id'=>$id]),'',1);
            } else {
                return $this->error('编辑失败！',url('Role/role_edit',['id'=>$id]),'',1);
            }
		}
		return $this -> fetch();
	}

	/***** 删除角色 *****/
    public function role_deleteAction(){
        $id    =  input('post.id');
        $one   =  Db::name('Role') -> where('id','=',$id) -> field('delete_id') -> update(array('delete_id'=> 1)); 
        return 1;
    }


    /***** 角色状态改变 *****/
    public function stateAction(){
        $id    =  input('post.id');
        $one   =  Db::name('Role') -> where('id',$id) -> field('state') -> find();  
        if ($one['state'] == 1) {
            $list  =  Db::name('Role') -> where('id',$id) ->  update(array('state'=> 0));  
            return 0;
        }else{
            $list  =  Db::name('Role') -> where('id',$id) ->  update(array('state'=> 1)); 
            return 1;
        }
   
    }

    /*****权限编辑*****/
    public function role_powerAction(){
    	$this -> islogin();
        $id = input('get.id');
        $one   =  Db::name('Role') -> where('id',$id) ->find();
        $list  = explode(',',$one['power_id']);//字符串转换成数组

        $powerA = Db::name('Power') -> where('level',0) -> select();
        $powerB = Db::name('Power') -> where('level',1) -> select();
        $powerC = Db::name('Power') -> where('level',2) -> select();

        $this->assign([
        	'name'  => $one,
        	'list'  => $list,
        	'powerA'  => $powerA,
        	'powerB'  => $powerB,
        	'powerC'  => $powerC
    	]);
        if (Request::instance()->isPost()) {
            $data = input('post.');        
            $id = $data['id'];
            $ac = $data['power_id'];
            $auth['role_ac'] = $this -> role_ac($ac);

            $role = Db::name('Role') -> where("id",$id) -> field('role_ac') ->data($auth) -> update();

            $datas['power_id'] = implode(',',$data['power_id']);//数组转换成字符串
            $ret = Db::name('Role') -> where("id",$id) -> field('power_id') ->data($datas) -> update();

            if ($ret > 0 || $role > 0) {
                $this -> success('配置成功！','','',1);exit;
            }elseif($ret === 0 || $role === 0){
                $this -> error('无数据更新！','','',1);exit;
            }else{
                $this -> error('配置失败！','','',1);exit;
            }
        }   
        return $this -> fetch();
    }



    public function role_ac($ac){
        $data['id'] = $ac;         
        $id = $data['id'];         
        $where['id'] = array('in',$id);
        $ret = Db::name('Power') -> where($where)  -> select();
        $role_ac = '';
        foreach ($ret as $ke => $va) {
            if (!empty($va['auth_c']) && !empty($va['auth_a'])) {
                $role_ac.=$va['auth_c'].'/'.$va['auth_a'].',';
            }      
        }
        $role_ac = rtrim($role_ac,',');
        return $role_ac;
    }




}