<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/9
 * Time: 17:29
 */

namespace app\admin\controller;

use think\Controller;
use think\Session;

class Index extends Base
{
	public function indexAction(){
		$adminpower = $this -> power();
		$this -> islogin();
		$this->controller();
		$this -> assign([
			'adminpower'  => $adminpower
		]);
		return $this -> fetch();
	}

	public function welcomeAction(){
		return $this -> fetch();
	}


}