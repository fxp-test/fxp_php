<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/20
 * Time: 10:36
 */

namespace app\admin\controller;

use think\Controller;
use think\Request;
use think\Db;
use app\admin\model\Power as PowerModel;

class Power extends Base
{
	/***** 权限管理设置 *****/
    public function adddata($id){
        $new = Db::name('Power')  -> where('id',$id) -> find();
        if ($new['parent_id'] == 0) {
            $auth['auth'] = $new['id'];
            Db::name('Power')  -> field('auth') -> where('id',"$new[id]") -> update($auth);
         }else{
            $pid = Db::name('Power')   -> where("id","$new[parent_id]") -> find();
            $auth['auth'] = $pid['auth']."-".$new['id'];
            Db::name('Power')   -> field('auth') -> where('id',"$new[id]") -> update($auth);
         }
         $level = Db::name('Power')  -> where("id=$id") -> find();        
         $one['level'] = substr_count("$level[auth]","-");//判断$level[auth]中有‘-’的个数
         Db::name('Power')  -> field('level') -> where("id","$new[id]") -> update($one);
    }


    /***** 权限节点列表 *****/
	public function power_indexAction(){
        $adminpower = $this -> power();
		$this -> islogin();
    	$this -> controller();
        $power = PowerModel::getPowerAll();
        $count = count(Db::name('Power') -> where('delete_id',0) -> select());
        $page = $power->render();
        $this->assign([
            'power'  => $power,
            'count' => $count,
            'page'  => $page,
            'adminpower' => $adminpower
        ]);
		return $this -> fetch();
	}


	/***** 添加权限节点 *****/
	public function power_addAction(){
		$this -> islogin();
		$this -> controller();
		$list   = Db::name('Power')  -> order('auth') ->  select();  
    	// print_r($list);exit;     
        $this->assign('list',$list);
		if (Request::instance()->isPost()) {
			$data = input('post.');
    		$power = PowerModel::getModelOne($field = 'name' , $one = $data['name']);
            if (!empty($power)){
                $this -> error('权限名称已存在!','',1);exit;
            }           
            if (empty($data['name'])) {
                $this -> error('权限名称不能为空！','',1);exit;
            }
            if (empty($data['auth_c'])) {
                $this -> error('控制器不能为空！','',1);exit;
            }
            if (empty($data['auth_c'])) {
                $this -> error('操作方法不能为空！','',1);exit;
            }
//    		$validate = Validate('PowerValidate');
//            if (!$validate -> scene('add') -> check($data)) {
//                $this -> error($validate -> getError());
//            }
            $result = PowerModel::getPowerAdd($data); // 返回最新插入数据的id 
            $this ->  adddata($result); 
            if($result > 0){
                return $this->success('添加成功！','','',1);
            } else {
                return $this->error('添加失败！','','',1);
            }
		}
		return $this -> fetch();
	}


	/***** 编辑权限节点 *****/
	public function power_editAction(){
		$this -> islogin();
		if (Request::instance() -> isGet()) {
            $id = input('get.id');
    		$power = PowerModel::getModelOne($field = 'id' , $data = $id);
    		$powers   = Db::name('Power')  -> order('auth') ->  select(); 
    		$this->assign([
            	'power'  => $power,
            	'powers' => $powers
        	]);
    	}
		if (Request::instance()->isPost()) {
			$data = input('post.');
			$id = $data['id'];
    		$power = PowerModel::getModelOne($field = 'name' , $one = $data['name']);
            if (empty($data['name'])) {
                $this -> error('权限名称不能为空！',url('Power/power_edit',['id'=>$id]),'',1);exit;
            }
            if ($power['level'] !=0 ) {
                if (empty($data['auth_c'])) {
                    $this -> error('控制器不能为空！',url('Power/power_edit',['id'=>$id]),'',1);exit;
                }
                if (empty($data['auth_c'])) {
                    $this -> error('操作方法不能为空！',url('Power/power_edit',['id'=>$id]),'',1);exit;
                }
            }
//    		$validate = Validate('PowerValidate');
//            if (!$validate -> scene('edit') -> check($data)) {
//                $this -> error($validate -> getError());
//            }
            $result = PowerModel::getPowerEdit($id,$data);
            $this ->  adddata($id);
            if($result > 0){
                return $this->success('编辑成功！',url('Power/power_edit',['id'=>$id]),'',1);
            } else {
                return $this->error('编辑失败！',url('Power/power_edit',['id'=>$id]),'',1);
            }
		}
		return $this -> fetch();
	}

	/***** 删除权限节点 *****/
    public function power_deleteAction(){
        $id    =  input('post.id');
        $one   =  Db::name('Power') -> where('id','=',$id) -> field('delete_id') -> update(array('delete_id'=> 1)); 
        return 1;
    }

}