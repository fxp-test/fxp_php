<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/21
 * Time: 10:02
 */

namespace app\admin\controller;

use app\admin\model\Client as ClientModel;
use think\Request;

class Client extends Base
{
    public function clientIndexAction()
    {
        $this -> islogin();
        $this -> controller();
        $list = ClientModel::getClientList();
        $this -> assign([
            'list' => $list,
            'count' => count(ClientModel::getClientAll()),
            'page' => $list -> render()
        ]);
        return $this -> fetch();
    }

    public function clientAddAction()
    {
        if (Request::instance()->isPost()) {
            $data = input('post.');
            $validate = Validate('ClientValidate');
            if (!$validate -> scene('add') -> check($data)) {
                $this -> error($validate -> getError());
            }
            if( empty($data) || !is_array($data) )
            {
                return false;
            }
            $result = ClientModel::addClient($data);
            if ($result) {
                return json($result);
            } else {
                return false;
            }
        }

        $id = input('get.id');
        if ($id) {
            $data = ClientModel::getClientOne($id);
            $this -> assign([
                'data' => $data
            ]);
            return $this -> fetch('clientEdit');
        } else {
            return $this -> fetch();

        }

    }

    public function clientDeleteAction()
    {
        $ids['id'] = input('get.id');
        $str = implode("','",$ids);
        if (!empty($ids)) {
            $result = ClientModel::delClient($str);
            if ($result) {
                return json($result);
            } else {
                return false;
            }
        } else{
            return false;
        }
    }

    public function clientSearchAction()
    {
        $data = input('post.');
        if (!empty($data)) {
            $name = $data['name'];
            $list = ClientModel::searchClient($name);
            if ($list) {
                return json($list);
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function addressListAction()
    {
        $cid = input('get.id');
        $list = ClientModel::getAddressListByID($cid);
        $this -> assign([
            'cid' => $cid,
            'list' => $list
        ]);
        return $this -> fetch();
    }

    public function addressAddAction()
    {
        if (Request::instance()->isPost()) {
            $data = input('post.');
            if( empty($data) || !is_array($data) )
            {
                return false;
            }
            $result = ClientModel::addAddress($data);
            if ($result) {
                return json($result);
            } else {
                return false;
            }
        }

        $ids = input('get.');
        $this -> assign([
            'ids' => $ids,
        ]);
        if ( isset($ids['aid']) ) {
            $data = ClientModel::getAddressOne($ids['aid']);
            $this -> assign(['data' => $data]);
            return $this -> fetch('addressEdit');
        } else {
            return $this -> fetch();
        }
    }

    public function addressDeleteAction()
    {
        $id = input('get.id');
        if (!empty($id)) {
            $result = ClientModel::delAddress($id);
            if ($result) {
                return json($result);
            } else {
                return false;
            }
        } else{
            return false;
        }
    }

}