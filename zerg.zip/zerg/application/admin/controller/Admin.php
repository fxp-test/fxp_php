<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/9
 * Time: 17:29
 */

namespace app\admin\controller;

use think\Controller;
use think\Request;
use think\Db;
use app\admin\model\Admin as AdminModel;
use think\Session;
use think\Cookie;

class Admin extends Base
{
	/***** 管理员登录 ******/
    public function loginAction(){
    	if (Request::instance()->isPost()) {
    		$data = input('post.');
            // var_dump($data);exit;
    		$admin = AdminModel::getModelOne($field = 'name' , $one = $data['name']);
    		// print_r($admin);exit;
            if (empty($admin)) {
                $this -> error('账号有误！','','',1);exit;
            }
            if ($admin['password'] != md5($data['password'])) {
                $this -> error('密码有误！','','',1);exit;
            }
            if ($admin['state'] != 1) {
                $this -> error('用户已停用！','','',1);exit;
            }
            if ($admin['delete_id'] != 0) {
                $this -> error('用户已删除！','','',1);exit;
            }
            $id = $admin['id'];	
            $name = $data['name'];
            $password = $data['password'];
            $user = AdminModel::getAdminLogin($name,$password);	
//             print_r($user);exit;
            $role_ac =  explode(',',$user['role']['role_ac']);
            $role = $user['role']['name'];

            if (!empty($user)) {
            	$datas  = array(
					'login_ip' => request() -> ip(),
					'login_time' => time(),
					'login_s' => $user['login_s']+1
				);
	            $result = AdminModel::getLoginEdit($id,$datas);
                Session::set('administrator',$user);
                Session::set('power',$role_ac);
                Session::set('role',$role);
                Session::set('name',$data['name']);
                if (!empty($data['remember'])) {
                        Cookie::set('name',$_POST['name'],3600);
                        Cookie::set('password',$_POST['password'],3600);
                        Cookie::set('remember',$_POST['remember'],3600);
                    }else{
                        Cookie::delete('name',null);
                        Cookie::delete('password',null);
                        Cookie::delete('remember',null);
                    }
            	$this -> success('登录成功', url('Index/index'),'',1);exit;
            }else{
            	$this -> error('登录失败',url('Admin/login'),'',1);exit;
            }
    	}

        return $this -> fetch();
    }

    /***** 管理员退出 *****/
    public function logoutAction(){
    	$data['name'] = Session::get('administrator.name');;
    	$data['out_time'] = time();
    	$result = AdminModel::getLogoutEdit($field = $data['name'],$data);
        Session::delete('administrator');
    	$this -> success('退出成功！',url('Admin/login'),'',1);exit;
    }

    /***** 管理员列表 *****/
    public function admin_indexAction(){
        $adminpower = $this -> power();
    	$this -> islogin();
    	$this -> controller();
    	$admin = AdminModel::getAdminAll();
        $count = count(Db::name('admin') -> where('delete_id',0) -> select()); 
        $this->assign([
            'admin'  => $admin,
            'count' => $count,
            'adminpower'  => $adminpower
        ]);
        return $this -> fetch();
    }

    /***** 添加管理员 *****/
    public function admin_addAction(){
        $this -> islogin();
    	//判断是否POST提交
    	if (Request::instance()->isPost()) {
    		// print_r(request() -> post());
    		$data = input('post.');
    		// print_r($data);exit;
    		$admin = AdminModel::getModelOne($field = 'name' , $one = $data['name']);
            if (!empty($admin)){
	            $this -> error('管理员已存在!','','',1);
	        }
    		$validate = Validate('AdminValidate');
            if (!$validate -> scene('add') -> check($data)) {
                $this -> error($validate -> getError());
            }
            
            $result = AdminModel::getAdminAdd($data);
            if($result){
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                return $this->success('添加成功！','','',1);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                return $this->error('添加失败！','','',1);
            }
        }
    	return $this -> fetch();
    }

	/***** 编辑管理员 *****/
    public function admin_editAction(){
        $this -> islogin();
    	//判断是否GET提交
    	if (Request::instance() -> isGet()) {
            $id = input('get.id');
    		$admin = AdminModel::getModelOne($field = 'id' , $data = $id);
    		$this->assign([
            	'admin'  => $admin
        	]);
    	}
        if (Request::instance()->isPost()) {
            $data = input('post.');
            $id = $data['id'];
            $admin = AdminModel::getModelOne($field = 'name' , $one = $data['name']);
            if (!empty($admin)){
                $this->error('管理员已存在！',url('Admin/admin_edit',['id'=>$id]),'',1);
            }
            $validate = Validate('AdminValidate');
            if (!$validate -> scene('edit') -> check($data)) {
                $this -> error($validate -> getError());
            }                      
            $result = AdminModel::getAdminEdit($id,$data);
            if($result){
                $this->success('编辑成功！',url('Admin/admin_edit',['id'=>$id]),'',1);
            } else {
                $this->error('编辑成功！',url('Admin/admin_edit',['id'=>$id]),'',1);
            }
        }
        return $this -> fetch();
    }

    /***** 删除管理员 *****/
    public function admin_deleteAction(){
        $id    =  input('post.id');
        $one   =  Db::name('admin') -> where('id','=',$id) -> field('delete_id') -> update(array('delete_id'=> 1)); 
        return 1;
    }


    public function stateAction(){
        $id    =  input('post.id');
        $one   =  Db::name('admin') -> where('id','=',$id) -> field('state') -> find(); 
        if ($one['state'] == 1) {
            $list  =  Db::name('Admin')  -> where('id','=',$id) ->  update(array('state'=> 0)); 
            return 0; 
        }else{
            $list  =  Db::name('Admin')  -> where('id','=',$id) ->  update(array('state'=> 1)); 
            return 1; 
        }
    } 


}