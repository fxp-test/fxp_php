<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/14
 * Time: 9:39
 */

namespace app\admin\controller;


use think\Controller;
use think\Request;
use think\Session;

class Base extends Controller
{
    /***** 设置过滤字段 *****/
    protected $field = true;

	/***** 判断用户是否登录 *****/
	public function islogin(){
    	$session = Session::get('administrator');
    	if (empty($session)) {
    		$this -> error('请先登录！',url('Admin/login'),'',1);exit;
    	}	
    }

	/***** 获取控制器名称 *****/
    public function controller(){
        $controller = request()->controller();
        $this -> assign('controller',$controller);
    }

    /*****- 访问权限 *****/
    public function power(){
        if (!empty(Session::get('power'))) {
            $controller = request()->controller();
            $action = request() -> action();
            if (in_array($controller.'/'.$action, Session::get('power'))) {
                return 'Adopt';
                // $this -> error('对不起！您没有访问权限！','Index/index','',1);exit;
            }
            // if (!in_array($controller.'/'.$action, Session::get('power'))) {
            //     return 'Not-through';
            // }
        }
        
    }

}