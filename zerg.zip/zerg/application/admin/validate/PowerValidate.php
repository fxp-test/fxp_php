<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/20
 * Time: 10:37
 */

namespace app\admin\validate;


class PowerValidate
{

}