<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/19
 * Time: 14:46
 */

namespace app\admin\validate;


use think\Validate;

class RoleValidate extends Validate
{
	/***** 验证规则 *****/
	protected $rule = [
        'name'  =>  'require|max:20',
    ];


    /***** 错误信息 *****/
    protected $message  =   [
        'name.require' => '角色名称是必须的',
        'name.max'     => '角色名称最大不能超过20个字符',
    ];


    /***** 验证场景 *****/
    protected $scene = [
    	'add'  =>  ['name'], //添加
        'edit'  =>  ['name'], //编辑
    ];

}