<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/14
 * Time: 14:34
 */

namespace app\admin\validate;


use think\Validate;

class AdminValidate extends Validate
{
	/***** 验证规则 *****/
	protected $rule = [
		'real_name' => 'require',
        'name'  =>  'require|length:5,20|alphaNum',
        'email' =>  'email',
        'password' => 'require|alphaDash|length:6,20',
        'password_confirm' => 'confirm:password'
    ];


    /***** 错误信息 *****/
    protected $message  =   [
    	'real_name.require' => '姓名是必须的',
        'name.require' => '管理员名称是必须的',
        'name.length'     => '管理员名称的长度在5到20之间',
        'name.alphaNum'   => '管理员名称必须是字母和数字',
        'password.require'   => '密码是必须的',
        'password.alphaDash'   => '密码是字母和数字，下划线_及破折号-',
        'password.length'  => '密码的长度在6到20之间',
        'password_confirm.confirm'  => '两次输入的密码不一致',
        'email'        => '邮箱格式错误', 
    ];


    /***** 验证场景 *****/
    protected $scene = [
    	'add'  =>  ['real_name','name','email','password','password_confirm'], //添加
        'edit'  =>  ['real_name','name','email','password_confirm'], //编辑
    ];



}