<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/21
 * Time: 11:46
 */

namespace app\admin\validate;


class ClientValidate extends BaseValidate
{
    protected $rule = [
        'name' => 'require|max:32',
        'phone' => 'require|checkPhone',
    ];

    protected $message = [
        'name' => 'name不能为空，且不得超过16个字',
        'phone' => 'phone不能为空，且不得超过11个数字'
    ];

    protected $scene = [
        'add'  =>  ['name','phone'], //添加
        'edit'  =>  ['name','phone'], //编辑
    ];
}